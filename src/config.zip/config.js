module.exports = {
  google: {
    API_KEY: "",
    CLIENT_ID: "",
    SECRET: "",
  },
  facebook: {
    APP_ID: "",
  },
  api: {
    API_URL: "https://api-node.themesbrand.website",
    // ------------------Local-------------
    // LOCAL_URL:"http://localhost:8085",
    // APICALL_URL:"http://localhost:8085",

        // ------------------Quality-------------
    // LOCAL_URL: "http://20.198.26.8:8085",
    // APICALL_URL: "http://20.198.26.8:8085",

    // ------------------Cloud-------------
    // LOCAL_URL: "https://plmscements.firlo.io/eplms-master",
    // APICALL_URL: "https://plmscements.firlo.io/eplms-master",
  }
};